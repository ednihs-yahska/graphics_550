#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>
#include "glut.h"
#include <stdio.h>

struct Face {
    float x; float y; float z; float height; float width;
};

struct My3DPoint {
    float x;
    float y;
    float z;
};

struct FacePoints {
    My3DPoint p1; My3DPoint p2; My3DPoint p3; My3DPoint p4;
};

void CreateFace(Face face);

// void CreateCube(x, y, height, width, depth);
void CreateFaceWithPoints(My3DPoint p1, My3DPoint p2, My3DPoint p3, My3DPoint p4);

void Create3DPolygon(Face face_1, Face face_2);


void CreateFace(Face face) {
    glBegin(GL_TRIANGLE_STRIP);
        glVertex3f(face.x, face.y, face.z);
        glVertex3f(face.x, face.y+face.height, face.z);
        glVertex3f(face.x+face.width, face.y+face.height, face.z);
        glVertex3f(face.x+face.width, face.y, face.z); 
        glVertex3f(face.x, face.y, face.z);      
    glEnd();
}

void CreateFaceWithPoints(My3DPoint p1, My3DPoint p2, My3DPoint p3, My3DPoint p4){
    glBegin(GL_TRIANGLE_STRIP);
        glVertex3f(p1.x, p1.y, p1.z);
        glVertex3f(p2.x, p2.y, p2.z);
        glVertex3f(p3.x, p3.y, p3.z);
        glVertex3f(p4.x, p4.y, p4.z); 
        glVertex3f(p1.x, p1.y, p1.z);      
    glEnd();
}

void Create3DPolygon(Face face_1, Face face_2, int interpolation_unit) {
    My3DPoint f1_1 = {face_1.x, face_1.y, face_1.z};
    My3DPoint f1_2 = {face_1.x, face_1.y+face_1.height, face_1.z};
    My3DPoint f1_3 = {face_1.x+face_1.width, face_1.y+face_1.height, face_1.z};
    My3DPoint f1_4 = {face_1.x+face_1.width, face_1.y, face_1.z};

    My3DPoint f2_1 = {face_2.x, face_2.y, face_2.z};
    My3DPoint f2_2 = {face_2.x, face_2.y+face_2.height, face_2.z};
    My3DPoint f2_3 = {face_2.x+face_2.width, face_2.y+face_2.height, face_2.z};
    My3DPoint f2_4 = {face_2.x, face_2.y, face_2.z};

    My3DPoint dirVector1 = {f1_1.x - f2_1.x, f1_1.y - f2_1.y, f1_1.z - f2_1.z};
    My3DPoint dirVector2 = {f1_2.x - f2_2.x, f1_2.y - f2_2.y, f1_2.z - f2_2.z};
    My3DPoint dirVector3 = {f1_3.x - f2_3.x, f1_3.y - f2_3.y, f1_3.z - f2_3.z};
    My3DPoint dirVector4 = {f1_4.x - f2_4.x, f1_4.y - f2_4.y, f1_4.z - f2_4.z};

    My3DPoint midpoint_1 = {f1_1.x + 0.5*dirVector1.x, f1_1.y + 0.5*dirVector1.y, f1_1.z + 0.5*dirVector1.z};
    My3DPoint midpoint_2 = {f1_2.x + 0.5*dirVector2.x, f1_2.y + 0.5*dirVector2.y, f1_2.z + 0.5*dirVector2.z};
    My3DPoint midpoint_3 = {f1_3.x + 0.5*dirVector2.x, f1_3.y + 0.5*dirVector2.y, f1_3.z + 0.5*dirVector2.z};
    My3DPoint midpoint_4 = {f1_4.x + 0.5*dirVector2.x, f1_4.y + 0.5*dirVector2.y, f1_4.z + 0.5*dirVector2.z};

    CreateFaceWithPoints(f1_1, midpoint_1, midpoint_2, f1_2);
    CreateFace(face_1);
    CreateFace(face_2);
}

void
DoRasterString_( float x, float y, float z, char *s )
{
	glRasterPos3f( (GLfloat)x, (GLfloat)y, (GLfloat)z );

	char c;			// one character to print
	for( ; ( c = *s ) != '\0'; s++ )
	{
		glutBitmapCharacter( GLUT_BITMAP_TIMES_ROMAN_24, c );
	}
}

void Create3DPolygonWithFacePoints(FacePoints f1, FacePoints f2){
    My3DPoint dirVector1 = {f1.p1.x - f2.p1.x, f1.p1.y - f2.p1.y, f1.p1.z - f2.p1.z};
    My3DPoint dirVector2 = {f1.p2.x - f2.p2.x, f1.p2.y - f2.p2.y, f1.p2.z - f2.p2.z};
    My3DPoint dirVector3 = {f1.p3.x - f2.p3.x, f1.p3.y - f2.p3.y, f1.p3.z - f2.p3.z};
    My3DPoint dirVector4 = {f1.p4.x - f2.p4.x, f1.p4.y - f2.p4.y, f1.p4.z - f2.p4.z};

    float distance_1 = pow(pow(f1.p1.x - f2.p1.x, 2) + pow(f1.p1.y - f2.p1.y, 2) + pow(f1.p1.z - f2.p1.z,2), 0.5);
    float distance_2 = pow(pow(f1.p2.x - f2.p2.x, 2) + pow(f1.p2.y - f2.p2.y, 2) + pow(f1.p2.z - f2.p2.z,2), 0.5);
    float distance_3 = pow(pow(f1.p3.x - f2.p3.x, 2) + pow(f1.p3.y - f2.p3.y, 2) + pow(f1.p3.z - f2.p3.z,2), 0.5);
    float distance_4 = pow(pow(f1.p4.x - f2.p4.x, 2) + pow(f1.p4.y - f2.p4.y, 2) + pow(f1.p4.z - f2.p4.z,2), 0.5);

    float step1 = 1/distance_1;
    float step2 = 1/distance_2;
    float step3 = 1/distance_3;
    float step4 = 1/distance_4; 

    for(int step = 0; step<=distance_1; step++){
        My3DPoint p1 = f1.p1;
        My3DPoint p2 = f1.p2;
        My3DPoint p3 = f2.p1;
        My3DPoint p4 = f2.p2;

        if(step>0){
            float prevStepFactor1 = -step1;
            float prevStepFactor2 = -step2;
            p1.x = p1.x + prevStepFactor1*dirVector1.x; p1.y = p1.y + prevStepFactor1*dirVector1.y; p1.z = p1.z + prevStepFactor1*dirVector1.z;
            p2.x = p2.x + prevStepFactor2*dirVector2.x; p2.y = p2.y + prevStepFactor2*dirVector2.y; p2.z = p2.z + prevStepFactor2*dirVector2.z;
        }

        My3DPoint midpoint_1_1 = {p1.x + -step1*dirVector1.x, p1.y + -step1*dirVector1.y, p1.z + -step1*dirVector1.z};
        My3DPoint midpoint_1_2 = {p2.x + -step2*dirVector2.x, p2.y + -step2*dirVector2.y, p2.z + -step2*dirVector2.z};

        if(step==floor(distance_1)){
            midpoint_1_1 = p3;
            midpoint_1_2 = p4;
        }
        CreateFaceWithPoints(p1, midpoint_1_1, midpoint_1_2, p2);
    }

    for(int step = 0; step<=floor(distance_2); step++){
        My3DPoint p1 = f1.p2;
        My3DPoint p2 = f1.p3;
        My3DPoint p3 = f2.p2;
        My3DPoint p4 = f2.p3;

        if(step>0){
            float prevStepFactor1 = -step2;
            float prevStepFactor2 = -step3;
            p1.x = p1.x + prevStepFactor1*dirVector2.x; p1.y = p1.y + prevStepFactor1*dirVector2.y; p1.z = p1.z + prevStepFactor1*dirVector2.z;
            p2.x = p2.x + prevStepFactor2*dirVector3.x; p2.y = p2.y + prevStepFactor2*dirVector3.y; p2.z = p2.z + prevStepFactor2*dirVector3.z;
        }

        My3DPoint midpoint_1_1 = {p1.x + -step2*dirVector2.x, p1.y + -step2*dirVector2.y, p1.z + -step2*dirVector2.z};
        My3DPoint midpoint_1_2 = {p2.x + -step3*dirVector3.x, p2.y + -step3*dirVector3.y, p2.z + -step3*dirVector3.z};

        if(step==floor(distance_2)){
            midpoint_1_1 = p3;
            midpoint_1_2 = p4;
        }

        CreateFaceWithPoints(p1, midpoint_1_1, midpoint_1_2, p2);
    }

    for(int step = 0; step<=floor(distance_3); step++){
        My3DPoint p1 = f1.p3;
        My3DPoint p2 = f1.p4;
        My3DPoint p3 = f2.p3;
        My3DPoint p4 = f2.p4;
        if(step>0){
            float prevStepFactor1 = -step3;
            float prevStepFactor2 = -step4;
            p1.x = p1.x + prevStepFactor1*dirVector3.x; p1.y = p1.y + prevStepFactor1*dirVector3.y; p1.z = p1.z + prevStepFactor1*dirVector3.z;
            p2.x = p2.x + prevStepFactor2*dirVector4.x; p2.y = p2.y + prevStepFactor2*dirVector4.y; p2.z = p2.z + prevStepFactor2*dirVector4.z;
        }
        My3DPoint midpoint_1_1 = {p1.x + -step3*dirVector3.x, p1.y + -step3*dirVector3.y, p1.z + -step3*dirVector3.z};
        My3DPoint midpoint_1_2 = {p2.x + -step4*dirVector4.x, p2.y + -step4*dirVector4.y, p2.z + -step4*dirVector4.z};
        if(step==floor(distance_3)){
            midpoint_1_1 = p3;
            midpoint_1_2 = p4;
        }
        CreateFaceWithPoints(p1, midpoint_1_1, midpoint_1_2, p2);
    }

    for(int step = 0; step<=floor(distance_4); step++){
        My3DPoint p1 = f1.p4;
        My3DPoint p2 = f1.p1;
        My3DPoint p3 = f2.p4;
        My3DPoint p4 = f2.p1;
        if(step>0){
            float prevStepFactor1 = -step4;
            float prevStepFactor2 = -step1;
            p1.x = p1.x + prevStepFactor1*dirVector4.x; p1.y = p1.y + prevStepFactor1*dirVector4.y; p1.z = p1.z + prevStepFactor1*dirVector4.z;
            p2.x = p2.x + prevStepFactor2*dirVector1.x; p2.y = p2.y + prevStepFactor2*dirVector1.y; p2.z = p2.z + prevStepFactor2*dirVector1.z;
        }
        My3DPoint midpoint_1_1 = {p1.x + -step4*dirVector4.x, p1.y + -step4*dirVector4.y, p1.z + -step4*dirVector4.z};
        My3DPoint midpoint_1_2 = {p2.x + -step1*dirVector1.x, p2.y + -step1*dirVector1.y, p2.z + -step1*dirVector1.z};
        if(step==floor(distance_4)){
            midpoint_1_1 = p3;
            midpoint_1_2 = p4;
        }
        CreateFaceWithPoints(p1, midpoint_1_1, midpoint_1_2, p2);
    }

    CreateFaceWithPoints(f1.p1, f1.p2, f1.p3, f1.p4);
    CreateFaceWithPoints(f2.p1, f2.p2, f2.p3, f2.p4);  
}




